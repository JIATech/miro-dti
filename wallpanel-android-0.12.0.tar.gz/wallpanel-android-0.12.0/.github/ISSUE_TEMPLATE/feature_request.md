---
name: Feature request
about: Suggest an idea for this project
title: "[FEATURE]"
labels: ''
assignees: ''

---

**Your feature request. Please describe.**
What is the feature, why is it valuable to the community or application?

**NOTE**
We get many feature requests, each feature requires community support and also development time. Features that have no community support are not considered.   If you are not contributing to the feature, then the feature may not happen.
