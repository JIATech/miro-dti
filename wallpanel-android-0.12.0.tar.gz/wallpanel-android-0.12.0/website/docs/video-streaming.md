---
title: Webcam MJPEG Video Streaming
---

If video streaming is enabled, then the stream can be accessed with this URL:

```plain
http://yourip:2971/camera/stream
```
